/**
 * 
 */
/**
 * @author DELL
 *
 */
module baitap_2 {
	requires junit;
}