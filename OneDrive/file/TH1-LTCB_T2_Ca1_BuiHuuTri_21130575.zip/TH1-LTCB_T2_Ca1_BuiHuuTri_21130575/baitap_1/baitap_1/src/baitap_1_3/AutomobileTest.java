package baitap_1_3;

import junit.framework.TestCase;

public class AutomobileTest extends TestCase {
	//this is testing for constructor
public void testConstructor () {
	new Automobile("old",5000,1.23,true);
}
}
