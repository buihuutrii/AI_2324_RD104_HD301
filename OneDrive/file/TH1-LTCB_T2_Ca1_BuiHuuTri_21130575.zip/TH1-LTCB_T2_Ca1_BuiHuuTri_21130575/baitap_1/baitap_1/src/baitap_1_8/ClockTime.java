package baitap_1_8;

public class ClockTime {
int hours;
int minute;
/**
 * this is constructor
 * @param hours
 * @param minute
 */
public ClockTime(int hours, int minute) {
	
	this.hours = hours;
	this.minute = minute;
}

}
