package baitap_1_8;

public class Train {
Schedule schedule;
Route route;
boolean local;
/**
 * this is constructor
 * @param schedule
 * @param route
 * @param local
 */
public Train(Schedule schedule, Route route, boolean local) {
	
	this.schedule = schedule;
	this.route = route;
	this.local = local;
}

	
}
