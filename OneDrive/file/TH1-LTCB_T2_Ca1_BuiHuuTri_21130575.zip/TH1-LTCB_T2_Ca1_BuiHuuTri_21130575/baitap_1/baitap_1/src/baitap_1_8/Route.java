package baitap_1_8;

public class Route {
String origin;
String destination;
/**
 * this is constructor
 * @param origin
 * @param destination
 */
public Route(String origin, String destination) {
	
	this.origin = origin;
	this.destination = destination;
}

}
