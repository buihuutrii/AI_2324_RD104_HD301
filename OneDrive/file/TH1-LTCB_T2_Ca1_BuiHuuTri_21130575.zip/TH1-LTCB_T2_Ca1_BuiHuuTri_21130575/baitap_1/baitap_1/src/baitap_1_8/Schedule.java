package baitap_1_8;

class Schedule {
ClockTime departure;
ClockTime arrival;
/**
 * this is constructor
 * @param departure
 * @param arrival
 */
public Schedule(ClockTime departure, ClockTime arrival) {
	this.departure = departure;
	this.arrival = arrival;
}

}
