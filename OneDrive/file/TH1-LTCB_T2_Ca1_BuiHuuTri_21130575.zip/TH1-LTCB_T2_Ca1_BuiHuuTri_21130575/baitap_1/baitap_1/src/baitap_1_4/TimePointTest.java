package baitap_1_4;

import junit.framework.TestCase;

public class TimePointTest extends TestCase {

	public void testConstructor () {
		new TimePoint(1, 2, 3);
	}
}
