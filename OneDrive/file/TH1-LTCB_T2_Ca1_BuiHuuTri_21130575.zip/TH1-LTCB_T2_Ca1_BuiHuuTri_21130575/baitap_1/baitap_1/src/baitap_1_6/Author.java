package baitap_1_6;

public class Author {
    private String name;
    private int birthYear;
    /**
     * this is constructor
     * @param name
     * @param birthYear
     */
    public Author(String name, int birthYear) {
        this.name = name;
        this.birthYear = birthYear;
    }
}