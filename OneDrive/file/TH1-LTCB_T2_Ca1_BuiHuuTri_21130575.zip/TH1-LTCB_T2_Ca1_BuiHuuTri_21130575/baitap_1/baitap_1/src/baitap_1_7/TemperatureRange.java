package baitap_1_7;

public class TemperatureRange {
int low;
int high;
public TemperatureRange(int low, int high) {
	
	this.low = low;
	this.high = high;
}

}
