package baitap_1_7;

public class Date {
int day ;
int month;
int year;
/**
 * this is constructor
 * @param day
 * @param month
 * @param year
 */
public Date(int day, int month, int year) {
	
	this.day = day;
	this.month = month;
	this.year = year;
}

}
