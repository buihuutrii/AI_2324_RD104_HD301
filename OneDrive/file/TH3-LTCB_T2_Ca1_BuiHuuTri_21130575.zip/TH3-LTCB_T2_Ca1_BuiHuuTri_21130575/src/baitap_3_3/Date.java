package baitap_3_3;

public class Date {

private int day;

private int month;

private int year;
/**
 * this is constructor
 * example:
 * Date d1 = new Date(1, 3,2020);
	Date d2 = new Date(1, 4,2020); 
 * @param day
 * @param month
 * @param year
 */
public Date(int day, int month, int year) {

this.day = day;

this.month = month;

this.year = year;

}

}