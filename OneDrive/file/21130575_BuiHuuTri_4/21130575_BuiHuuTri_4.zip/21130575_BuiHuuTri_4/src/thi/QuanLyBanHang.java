package thi;
import java.util.ArrayList;
public class QuanLyBanHang {
	ArrayList<KhachHang> Danhsachkhachhang =new ArrayList<KhachHang>();
	
	public QuanLyBanHang(ArrayList<thi.KhachHang> danhsachkhachhang) {
		Danhsachkhachhang = danhsachkhachhang;
	}
	public String getMaKH(String maKH) {
		return maKH;
				}
		
	public String gettenKH(String tenKH) {
		return tenKH;
	}
		
		public String getkhachhang(String tenKH,String maKH) {
		
		
		}
		public String buy(ArrayList KhachHang) {
			 if ()
			
		}
	}
		