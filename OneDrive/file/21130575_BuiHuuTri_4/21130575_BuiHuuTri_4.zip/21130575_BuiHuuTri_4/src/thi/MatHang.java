package thi;

public class MatHang {
	String maMH;
	String tenMH;
	double dongia;
	public MatHang(String maMH, String tenMH, double dongia) {
		this.maMH = maMH;
		this.tenMH = tenMH;
		this.dongia = dongia;
	}

}
